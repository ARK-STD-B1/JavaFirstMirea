# Практическая работа 19. Создание пользовательских исключений
Практическая работа №19 дисциплине «[Программирование на языке Джава](https://online-edu.mirea.ru/course/view.php?id=4053)» (РТУ МИРЭА, ИИТ, 2-ой курс).

**Преподаватель**: Ермаков Сергей Романович, ermakov_s@mirea.ru, ermakov@sumirea.ru.

## Задание на практическую работу

Создать пользовательские исключение. Пример есть в пакете examples.

## Альтернативное задание

1. Создайте класс прямоугольного треугольника, для создания треугольника вводятся значения углов. Если углы заданы неверно - реализуется исключение, созданное вами. 

## Дополнительные материалы

[Исключения java с примерами, try catch throws exception (javarush.ru)](https://javarush.ru/groups/posts/isklyucheniya-java)

[Исключения в Java (javarush.ru)](https://javarush.ru/groups/posts/2433-iskljuchenija-v-java)

[Java. Класс Exception. Создание собственных классов исключений. Примеры | BestProg](https://www.bestprog.net/ru/2019/10/01/java-class-exception-create-custom-exception-classes-examples-ru/#q02)

