package ru.mirea.task25;

public interface Shape
{
    void  draw();
}
