package ru.mirea.task2.opt1;

public class ShapeTester
{
    public static void main(String[] args)
    {
        Shape square = new Shape("Square", 10, 10);
        System.out.println(square.toString());
    }
}