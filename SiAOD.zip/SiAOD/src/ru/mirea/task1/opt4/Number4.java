package ru.mirea.task1.opt4;

public class Number4
{
    public static void main(String[] args)
    {
        System.out.println("Aргументы командной строки");

        for (int i = 0; i < args.length; i++)
        {
            System.out.println(args[i]);
        }
    }
}
