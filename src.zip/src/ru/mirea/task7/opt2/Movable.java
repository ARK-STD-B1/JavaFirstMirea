package ru.mirea.task7.opt2;

public interface Movable
{
    void moveUp();
    void moveDown();
    void moveLeft();
    void moveRight();
}