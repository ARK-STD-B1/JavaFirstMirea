package ru.mirea.task26;

public interface PaymentStrategy
{
    void askData();
}