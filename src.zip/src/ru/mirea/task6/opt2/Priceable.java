package ru.mirea.task6.opt2;

public interface Priceable
{
    String getPrice();
}