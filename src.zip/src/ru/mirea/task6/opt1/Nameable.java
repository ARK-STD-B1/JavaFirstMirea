package ru.mirea.task6.opt1;

public interface Nameable
{
    String getName();
}