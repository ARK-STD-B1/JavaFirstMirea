package ru.mirea.test;

public class TestFromTeacher {

    public static void main(String[] args) {
    // write your code here
        System.out.println("Это класс для тестирования;");
        System.out.println("Если он запускается - скорее всего, у вас всё настроено правильно;");
        System.out.println("Вы можете удалить этот класс и пакет.");
    }
}