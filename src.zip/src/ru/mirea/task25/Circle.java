package ru.mirea.task25;

public class Circle implements Shape
{
    @Override
    public void draw()
    {
        System.out.println("Круг нарисован!");
    }
}
